exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' }, body: '' };
  }
  const headers = { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json' };
  try {
    const { images, language } = JSON.parse(event.body);
    const langInstr = language === 'da' ? 'Respond in Danish.' : language === 'zh' ? 'Respond in Simplified Chinese.' : 'Respond in English.';
    const systemPrompt = `You are an expert alpine ski instructor with 25+ years of experience, certified according to Den Danske Skiskoles alpine methodology.\n\n${langInstr}\n\nYou will receive 10 frames from a ski video. First SELECT the best frames, then ANALYZE them.\n\nSTEP 1 - FRAME SELECTION:\nSelect frames showing these 5 key moments based on ski tip direction relative to camera:\n1. EARLY TURN: Ski tips 40-60 degrees away from camera\n2. APPROACHING FALL LINE: Ski tips 20-30 degrees away from camera\n3. FALL LINE: Ski tips pointing directly toward camera - most important frame\n4. STEERING PHASE: Ski tips 20-30 degrees away on opposite side\n5. EDGE CHANGE: Both ski tips nearly parallel and horizontal\n\nIgnore frames where skier is too small, blurry, partially out of frame, or technique is not visible.\n\nSTEP 2 - ANALYSIS:\nEvaluate selected frames on these 8 development points:\n1. FLADE SKI: Skis flat, no edge angle, sliding sideways\n2. FOR STOR SKRIDTSTILLING: Ski tips heavily offset, skis working against each other\n3. STIVE SKILED: Body rigid, no flex or extension through turn\n4. UHENSIGTSMÆSSIGE BØJEFORHOLD: Knees far forward with upright torso OR torso forward with vertical lower legs\n5. HOFTEROTATION: Hips rotate through turn, visible skidding\n6. OVERKROPSROTATION: Upper body rotates into turn, outside shoulder leads, arms swing\n7. BAGVÆGT: Weight on back of boot, hips behind heels, ski tips may lift\n8. INDOVERLÆNING: Excessive lean into turn, too much weight on inner ski, inside hip drops\n\nTONE: Honest and direct. Only mention strengths genuinely visible. Never invent praise. Max 150 words.\n\nUse EXACTLY these headers:\n✓ STRENGTHS:\n→ FOCUS:\n⬤ EXERCISE:\n💬 REMEMBER:\n\nSkip STRENGTHS entirely if nothing genuine to say.`;
    const imageContent = images.flatMap((b64, i) => ([{ type: 'text', text: `Frame ${i+1} of ${images.length}` }, { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: b64 } }]));
    const response = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' }, body: JSON.stringify({ model: 'claude-opus-4-5', max_tokens: 1000, system: systemPrompt, messages: [{ role: 'user', content: [{ type: 'text', text: 'Select the best frames and analyse my ski technique.' }, ...imageContent] }] }) });
    const data = await response.json();
    if (!response.ok) return { statusCode: response.status, headers, body: JSON.stringify({ error: data?.error?.message || 'API error' }) };
    const text = (data.content || []).map(c => c.text || '').join('').trim();
    return { statusCode: 200, headers, body: JSON.stringify({ text }) };
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
  }
};
