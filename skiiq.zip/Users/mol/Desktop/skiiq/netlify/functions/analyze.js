exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
      },
      body: ''
    };
  }

  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  };

  try {
    const { images, language } = JSON.parse(event.body);
    const langInstr = language === 'da' ? 'Respond in Danish.' : language === 'zh' ? 'Respond in Simplified Chinese.' : 'Respond in English.';

    const systemPrompt = `You are an expert alpine ski instructor. Analyze images of recreational skiers.\n\n${langInstr}\n\nEvaluate these 8 points:\n1. FLADE SKI: Skis flat, no edge angle\n2. FOR STOR SKRIDTSTILLING: Ski tips heavily offset\n3. STIVE SKILED: Body rigid, no flex\n4. UHENSIGTSMÆSSIGE BØJEFORHOLD: Poor flex ratios\n5. HOFTEROTATION: Hips rotate through turn\n6. OVERKROPSROTATION: Upper body rotates, arms swing\n7. BAGVÆGT: Weight on back of boot\n8. INDOVERLÆNING: Excessive lean into turn\n\nTONE: Honest, direct, max 150 words.\n\nUse EXACTLY these headers:\n✓ STRENGTHS:\n→ FOCUS:\n⬤ EXERCISE:\n💬 REMEMBER:\n\nSkip STRENGTHS if nothing genuine to say.`;

    const imageContent = images.flatMap((b64, i) => ([
      { type: 'text', text: `Frame ${i+1}` },
      { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: b64 } }
    ]));

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{ role: 'user', content: [{ type: 'text', text: 'Analyse these ski frames.' }, ...imageContent] }]
      })
    });

    const data = await response.json();
    if (!response.ok) return { statusCode: response.status, headers, body: JSON.stringify({ error: data?.error?.message || 'API error' }) };

    const text = (data.content || []).map(c => c.text || '').join('').trim();
    return { statusCode: 200, headers, body: JSON.stringify({ text }) };

  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
  }
};
